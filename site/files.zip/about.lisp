(in-package #:bog-pages)

(bog:defpage ()
  (bog:with-page (:title "About"
                  :description "About this bog test site")
    (:h1 "About")
    (:p "This is a static " (:code ".lisp") " page rendered via "
        (:code "defpage") " with no " (:code ":mutable") " flag.")
    (:p "Unlike MD and HTML pages, lisp pages bypass the preprocess/postprocess
        pipeline entirely. Heading normalization does " (:em "not") " apply here —
        the " (:code "h*") " macro handles that natively.")
    (:h2 "What to verify")
    (:ul
     (:li "This page title is \"About\" (check browser tab and " (:code "<title>") ")")
     (:li "The site name in the header links back to /")
     (:li "The " (:code "<meta name=\"description\">") " is set")
     (:li "This h2 rendered correctly (not shifted — lisp pages are exempt)"))
    (:h2 "Cache behavior")
    (:p "This is a static page. It will be cached after the first request and
        served from cache on subsequent requests. Changing this file and saving
        will invalidate the cache on next request (mtime check).")
    (:p (:a :href "/" "← Home"))))
