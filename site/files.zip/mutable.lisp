(in-package #:bog-pages)

(bog:defpage (:mutable t)
  (bog:with-page (:title "Mutable Page")
    (:h1 "Mutable Page")
    (:p "This page is declared " (:code "(:mutable t)") ". It bypasses the cache
        and re-renders on every request.")
    (:h2 "Live values")
    (:dl
     (:dt "Render time")
     (:dd (multiple-value-bind (s m h) (decode-universal-time (get-universal-time))
            (format nil "~2,'0d:~2,'0d:~2,'0d" h m s)))
     (:dt "Random number")
     (:dd (write-to-string (random 1000000))))
    (:h2 "What to verify")
    (:ul
     (:li "Reload this page — the render time and random number should change")
     (:li "The static " (:a :href "/about" "About") " page does " (:em "not") " change on reload"))
    (:p (:a :href "/" "← Home"))))
